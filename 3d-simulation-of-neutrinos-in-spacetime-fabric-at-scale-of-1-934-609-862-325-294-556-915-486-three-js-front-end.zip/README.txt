A Pen created at CodePen.io. You can find this one at http://codepen.io/Sander-Nizni/pen/JXZrYG.

 Enjoy this multi-color spacetime fabric, if not for its grotesque scale, then for its brutally realistic virtual reality effects. Whoa... did I say you should try this with 3D goggles on? Oh, now I did. Observe. Disobey. Enjoy and share.